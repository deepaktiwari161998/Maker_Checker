package com.sss.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sss.model.TempData;
import com.sss.service.MainDataRowMapper;
import com.sss.service.TempDataRowMapper;

@Repository
public class TempDataDaoImpl implements TempDataDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;



	@Override
	public List<TempData> getAllTempData() {
		String query = "SELECT * FROM temp_table";
		return jdbcTemplate.query(query, new TempDataRowMapper());
	}

	@Override
	public TempData getTempDataById(int id) {
		String query = "SELECT * FROM temp_table WHERE id = ?";
		return jdbcTemplate.queryForObject(query, new Object[] { id }, new TempDataRowMapper());
		

	}

	@Override
	public void addTempData(TempData tempData) {
		String query = "INSERT INTO temp_table (name, email) VALUES (?, ?)";
		jdbcTemplate.update(query, tempData.getName(), tempData.getEmail());
	}
	
	//add here approval_status=1

	@Override
	public void updateTempData(TempData tempData) {
		
		String query = "UPDATE temp_table SET name = ?, email = ?, approval_status=0 WHERE id = ?";
		//String query1 = "UPDATE main_table SET name = ?, email = ? WHERE id = ?";
		
		
		jdbcTemplate.update(query, tempData.getName(), tempData.getEmail(), tempData.getId());
		//jdbcTemplate.update(query1, tempData.getName(), tempData.getEmail(), tempData.getId());
		
		
	}

	@Override
	public void deleteTempData(int id) {
		String query = "DELETE FROM temp_table WHERE id = ?";
		jdbcTemplate.update(query, id);
	}

	@Override
	public void approveData(int id) {
		String query = "UPDATE temp_table SET approval_status = 1 WHERE id = ?";
		jdbcTemplate.update(query, id);
	}

	@Override
	public void rejectData(int id) {
		String query = "UPDATE temp_table SET approval_status = 0 WHERE id = ?";
		jdbcTemplate.update(query, id);
	}
}