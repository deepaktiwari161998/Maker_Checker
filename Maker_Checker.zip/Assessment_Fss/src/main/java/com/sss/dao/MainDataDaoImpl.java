package com.sss.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sss.model.MainData;
import com.sss.model.TempData;
import com.sss.service.MainDataRowMapper;
import com.sss.service.TempDataRowMapper;

@Repository
public class MainDataDaoImpl implements MainDataDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<MainData> getAllMainData() {
        String query = "SELECT * FROM main_table";
        return jdbcTemplate.query(query, new MainDataRowMapper());
    }

	public void addMainData(MainData mainData) {
		String sql = "INSERT INTO main_table (name, email) VALUES (?, ?)";
		jdbcTemplate.update(sql, mainData.getName(), mainData.getEmail());
	}

    @Override
    public MainData getMainDataById(int id) {
       String query = "SELECT * FROM main_table WHERE id = ?";
       return jdbcTemplate.queryForObject(query, new Object[]{id}, new MainDataRowMapper());

    }
    //one change here

    @Override
    public void updateMainData(MainData mainData) {
        String query = "UPDATE main_table SET name = ?, email = ? WHERE id = ?";
        jdbcTemplate.update(query, mainData.getName(), mainData.getEmail(), mainData.getId());
        
    }

    @Override
    public void deleteMainData(int id) {
        String query = "DELETE FROM main_table WHERE id = ?";
        jdbcTemplate.update(query, id);
    }
    
}
