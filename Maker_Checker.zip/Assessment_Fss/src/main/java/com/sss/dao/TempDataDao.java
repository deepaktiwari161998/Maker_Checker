package com.sss.dao;

import java.util.List;

import com.sss.model.TempData;

public interface TempDataDao {
    List<TempData> getAllTempData();
    TempData getTempDataById(int id);
    void addTempData(TempData tempData);
    void updateTempData(TempData tempData);
    void deleteTempData(int id);
    void approveData(int id);
    void rejectData(int id);
	
}