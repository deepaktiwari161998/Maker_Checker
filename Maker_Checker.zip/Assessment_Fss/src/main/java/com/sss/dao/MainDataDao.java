package com.sss.dao;

import java.util.List;

import com.sss.model.MainData;
import com.sss.model.TempData;


public interface MainDataDao {
    List<MainData> getAllMainData();
    void addMainData(MainData mainData);
    
    void updateMainData(MainData mainData);
    void deleteMainData(int id);
    MainData getMainDataById(int id);
   
    
}