package com.sss.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.sss.model.MainData;
import com.sss.model.TempData;
import com.sss.service.DataService;



@Controller
public class LoginController {

    private static final String ADMIN_MAKER_USERNAME = "admin-maker";
    private static final String ADMIN_MAKER_PASSWORD = "admin123";
    private static final String ADMIN_CHECKER_USERNAME = "admin-checker";
    private static final String ADMIN_CHECKER_PASSWORD = "admin321";

    @Autowired
    private DataService dataService;

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        if (username.equals(ADMIN_MAKER_USERNAME) && password.equals(ADMIN_MAKER_PASSWORD)) {
            return "redirect:/admin-maker";
        } else if (username.equals(ADMIN_CHECKER_USERNAME) && password.equals(ADMIN_CHECKER_PASSWORD)) {
            return "redirect:/admin-checker";
        } else {
            return "redirect:/login?error";
        }
    }

    @GetMapping("/admin-maker")
    public String adminMakerPage(Model model) {
        model.addAttribute("mainDataList", dataService.getAllMainData());
        return "admin-maker";
    }

    @GetMapping("/admin-checker")
    public String adminCheckerPage(Model model) {
        model.addAttribute("tempDataList", dataService.getAllTempData());
        return "admin-checker";
    }



    @PostMapping("/admin-maker/add-temp-data")
    public String addTempData(@ModelAttribute("tempData") TempData tempData) {
        dataService.addTempData(tempData);
        return "redirect:/admin-maker";
    }
    
    //add
    @GetMapping("/admin-maker/update-temp-data/{id}")
    public String showUpdateTempDataPage(@PathVariable("id") int id, Model model) {
       TempData tempData = dataService.getTempDataById(id);
        model.addAttribute("tempData", tempData);
       return "update-temp-data";
        
       
    }

    @PostMapping("/admin-maker/update-temp-data/{id}")
    public String updateTempData(@PathVariable("id") int id, @ModelAttribute("tempData") TempData tempData) {
        dataService.updateTempData(id, tempData);
    return "redirect:/admin-maker";
   }
    

       

//   @PostMapping("/admin-maker/approve-data/{id}")
//    public String approveData(@PathVariable("id") int id) {
//        dataService.approveData(id);
//       return "redirect:/admin-maker";
//   }
    
    
   //here today change
   @PostMapping("/admin-maker/approve-data/{id}")
   public String approveData(@PathVariable("id") int id) {
       dataService.approveData(id);
       return "redirect:/admin-maker";
  }
    
   
    
    //similiary

   @PostMapping("/admin-maker/reject-data/{id}")
       public String rejectData(@PathVariable("id") int id) {
       dataService.rejectData(id);
       return "redirect:/admin-maker";
       }

    @PostMapping("/admin-maker/delete-temp-data/{id}")
    public String deleteTempData(@PathVariable("id") int id) {
        dataService.deleteTempData(id);
        return "redirect:/admin-maker";
    }

   @PostMapping("/admin-maker/add-main-data")
   public String addMainData(@ModelAttribute("mainData") MainData mainData) {
       dataService.addMainData(mainData);
        return "redirect:/admin-maker";
    }
    
    //add here
//    
  @GetMapping("/admin-maker/update-main-data/{id}")
    public String showUpdateMainDataPage(@PathVariable("id") int id, Model model) {
        TempData tempData = dataService.getTempDataById(id);
       model.addAttribute("tempData", tempData);
       return "update-temp-data";
    }

  @PostMapping("/admin-maker/update-main-data/{id}")
   public String updateMainData(@PathVariable("id") int id, @ModelAttribute("mainData") MainData mainData) {
       mainData.setId(id);
       dataService.updateMainData(mainData);//id write here
      return "redirect:/admin-maker";
      }

    
    
    @GetMapping("/admin-maker/delete-temp-data/{id}")
    public String showDeleteTempDataPage(@PathVariable("id") int id, Model model) {
        TempData tempData = dataService.getTempDataById(id);
        model.addAttribute("tempData", tempData);
        return "delete-temp-data";
    }


  @PostMapping("/admin-maker/delete-main-data/{id}")
    public String deleteMainData(@PathVariable("id") int id) {
        dataService.deleteMainData(id);
        return "redirect:/admin-maker";
    }
    
    @GetMapping("/admin-maker/delete-main-data/{id}")
    public String showDeleteMainDataPage(@PathVariable("id") int id, Model model) {
        MainData mainData = dataService.getMainDataById(id);
       model.addAttribute("mainData", mainData);
       return "delete-main-data";
    }
    
    //add new code here
    @PostMapping("/user-details/{id}")
    public String getUserDetails(@PathVariable("id") int id, Model model) {
        TempData tempData = dataService.getTempDataById(id);
        model.addAttribute("tempData", tempData);
        return "user-details";
    }
        
}

