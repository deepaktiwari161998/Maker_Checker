package com.sss.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.sss.model.TempData;

public class TempDataRowMapper implements RowMapper<TempData> {

    @Override
    public TempData mapRow(ResultSet rs, int rowNum) throws SQLException {
        TempData tempData = new TempData();
        tempData.setId(rs.getInt("id"));
        tempData.setName(rs.getString("name"));
        tempData.setEmail(rs.getString("email"));
        tempData.setApprovalStatus(rs.getInt("approval_status"));
        return tempData;
    }
}