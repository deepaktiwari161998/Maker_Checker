package com.sss.service;

import java.util.List;

import com.sss.model.MainData;
import com.sss.model.TempData;

public interface DataService {
    List<TempData> getAllTempData();
    TempData getTempDataById(int id);
    void addTempData(TempData tempData);
    void updateTempData(int id, TempData tempData);
    void deleteTempData(int id);
    
    void rejectData(int id);
    List<MainData> getAllMainData();
    void addMainData(MainData mainData);
    void updateMainData(MainData mainData);
    void deleteMainData(int id);
    MainData getMainDataById(int id);

    void approveData(int id);
   
   
    

}