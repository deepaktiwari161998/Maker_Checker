package com.sss.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.sss.model.MainData;

public class MainDataRowMapper implements RowMapper<MainData> {

    @Override
    public MainData mapRow(ResultSet rs, int rowNum) throws SQLException {
        MainData mainData = new MainData();
        mainData.setId(rs.getInt("id"));
        mainData.setName(rs.getString("name"));
        mainData.setEmail(rs.getString("email"));
        return mainData;
    }
}