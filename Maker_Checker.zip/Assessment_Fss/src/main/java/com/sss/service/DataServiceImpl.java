package com.sss.service;


import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sss.dao.MainDataDao;
import com.sss.dao.TempDataDao;
import com.sss.model.MainData;
import com.sss.model.TempData;

@Service
@Transactional
public class DataServiceImpl implements DataService {
	
	
	

    @Autowired
    private TempDataDao tempDataDao;

    @Autowired
    private MainDataDao mainDataDao;

    @Override
    public List<TempData> getAllTempData() {
        return tempDataDao.getAllTempData();
    }

    @Override
    public TempData getTempDataById(int id) {
        return tempDataDao.getTempDataById(id);
    }
    
    @Override
    public MainData getMainDataById(int id) {
        return  mainDataDao.getMainDataById(id);
    }

    @Override
    public void addTempData(TempData tempData) {
        tempDataDao.addTempData(tempData);
    }

    
    
    
	@Override
	public void updateTempData(int id, TempData tempData) {
		TempData existingTempData = tempDataDao.getTempDataById(id);
		if (existingTempData != null) {
		existingTempData.setName(tempData.getName());
			existingTempData.setEmail(tempData.getEmail());
		tempDataDao.updateTempData(existingTempData);
	
		
	}	
	}
   
   
    
    @Override
    public void deleteTempData(int id) {
        tempDataDao.deleteTempData(id);
    }

 

   @Override
    public void rejectData(int id) {
        tempDataDao.rejectData(id);
   }

    @Override
    public List<MainData> getAllMainData() {
        return mainDataDao.getAllMainData();
    }
    
    @Override
    public void addMainData(MainData mainData) {
        mainDataDao.addMainData(mainData);
    }

//    @Override
//    public void updateMainData(MainData mainData) {
//    	//mainData.setId(id);
//     
//    	 mainDataDao.updateMainData(mainData);
//    	 //tempDataDao.updateTempData(mainData);
//   }
    
//    	 

     
    @Override
    public void updateMainData(MainData mainData) {
         //mainData.setId(id);
       mainDataDao.updateMainData(mainData);
       
    }
    	
//
//        // Check if the data is already approved
//        TempData tempData = tempDataDao.getTempDataById(id);
//        if (tempData != null && tempData.getApprovalStatus() == 0) {
//            // Update the approval status of tempData
//            tempDataDao.approveData(id);
//
//            // Delete the data from the temptablelist
//            tempDataDao.deleteTempData(id);
//        }
//    }
    
     
    @Override
    public void deleteMainData(int id) {
        mainDataDao.deleteMainData(id);
        tempDataDao.deleteTempData(id);
    }
    
	   
  @Override
 public void approveData(int id) {
	   TempData tempData = tempDataDao.getTempDataById(id);

       // Check if the data is already approved
       if (tempData != null && tempData.getApprovalStatus() ==0)        	
    {
//  
    	   
//    	   
//      // Update the approval status of tempData
     	tempDataDao.approveData(id);
//        
////         // Insert into main_table
////        MainData mainData = new MainData();
////         mainData.setName(tempData.getName());
////         mainData.setEmail(tempData.getEmail());  // tempData.setApprovalStatus(1);
////         mainDataDao.addMainData(mainData);
     	try {
   	       MainData mainData = mainDataDao.getMainDataById(id);
        if (mainData != null) {
            // Update existing data in main_table
            mainData.setName(tempData.getName());
            mainData.setEmail(tempData.getEmail());
            mainDataDao.updateMainData(mainData);
          // tempDataDao.deleteTempData(id);
            
            //tempData.setApprovalStatus(2);
      }
           
       else {
           // Insert new data into main_table
   	 
           mainData = new MainData();
           mainData.setId(tempData.getId());
            mainData.setName(tempData.getName());
           mainData.setEmail(tempData.getEmail());
           mainDataDao.addMainData(mainData);
           
           
           //tempData.setApprovalStatus(1);
        }
       
     }
     	
    
     	catch (EmptyResultDataAccessException ex) {
            // Handle the case when no record is found in main_table
           // Insert new data into main_table
            MainData mainData = new MainData();
            mainData.setId(tempData.getId());
            mainData.setName(tempData.getName());
            mainData.setEmail(tempData.getEmail());
           mainDataDao.addMainData(mainData);
           //tempData.setApprovalStatus(1);
           
           
        }
     	
//     	 tempData.setName(tempData.getName());
//        tempData.setEmail(tempData.getEmail());
        //tempDataDao.updateTempData(tempData);
     	
     	//tempDataDao.deleteTempData(id);
    }
      // tempDataDao.deleteTempData(id);
  }
       	 
  }
    
   
	   



